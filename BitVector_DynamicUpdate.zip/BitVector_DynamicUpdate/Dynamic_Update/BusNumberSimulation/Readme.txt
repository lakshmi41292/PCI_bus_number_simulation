How to execute the program

	1) Install VC++ redistributable package if not installed already.

	2) Create a config file describing the device tree in a depth first search pattern.

		( - Indicates Child.

		) - Indicates Parent.

		, - Indicates Sibling.

		R - Indicates Root Port.

		P - Indicates P2P Bridge.

		H - Indicates Host Bridge.

		U - Indicates Up Stream Port.

		S - Indicates Down Stream Port.

		D - Indicates Any Device.


		Always start with a open paranthesis "(" and end with a close paranthesis ")".


		Example config file is provided in the folder.


	3) Open command prompt and change directory to the executable directory.

	4) Execute the following command.

		BusNumberSimulation.exe <Start Bus Number> <End Bus Number> <Path to Config File> > <Output File Name>

		Example:

			BusNumberSimulation.exe 6 245 Tbt.cfg > TbtResults.txt