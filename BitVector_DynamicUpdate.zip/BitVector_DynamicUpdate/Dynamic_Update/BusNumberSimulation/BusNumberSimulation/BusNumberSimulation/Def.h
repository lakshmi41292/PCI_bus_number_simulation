#pragma once

typedef enum _NODE_TYPE
{

    DEVICE = 0,
    UP_STREAM = 1,
    DOWN_STREAM = 2,
	HOST_BRIDGE = 3,
    ROOT_PORT = 4,
	DEV_TREE_ROOT = 5,
	P2P = 6

} NODE_TYPE;

typedef enum _CREATE_STATUS
{
    LEFT_CHILD = 0,
    RIGHT_SIBLING = 1

} CREATE_STATUS;