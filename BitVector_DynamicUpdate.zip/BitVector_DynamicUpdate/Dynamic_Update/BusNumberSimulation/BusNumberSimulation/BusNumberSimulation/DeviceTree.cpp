#include "stdafx.h"

#include <iostream>
#include <fstream>
#include <ios>
#include <deque>
#include <bitset>
#include "DeviceTree.h"

using namespace std;

typedef deque <CDeviceNode*> DEVICE_NODE_QUEUE;

//global that stores the value of the next bus number 

//static char 0;

CDeviceTree::CDeviceTree(unsigned __int8 StartBusNumber, unsigned __int8 EndBusNumber)
{
    this->RootNode = new CBridgeNode(NULL, DEV_TREE_ROOT);

	this->RootNode->SecondaryBusNumber = 0;

	this->RootNode->SubordinateBusNumber = 0;

	//this->MaxBusNumber = EndBusNumber;

	//0 = StartBusNumber;

    this->CreateStatus = LEFT_CHILD;
}


                                                
bool
CDeviceTree::ConstructDeviceTree(char *FileName)
{
    bool status = true;

    fstream cfgFile;

    char currentCharacter;

	CDeviceNode *currentNode = this->RootNode;

    //
    // Open Config file.
    // 

    cfgFile.open(FileName, ios_base::in);

    if (cfgFile.is_open()) {

        while (!cfgFile.eof()) {

            cfgFile.get(currentCharacter);

            status = ConstructNextNode(currentCharacter, &currentNode);

            if (status == false) {

                break;

            }

        }

        if (status) {

            AssignBusNumbers();

        }

        //
        // Close the file.
        // 

        cfgFile.close();

    } else {

		cout << "Error occured  while trying to open the specified file." << endl;

        status = false;

    }

    return status;
    
}

bool
CDeviceTree::ConstructNextNode(char CurrentCharacter, CDeviceNode** CurrentNode)
{

    bool status = true;

	CDeviceNode *currentNode;

    NODE_TYPE nodeType;

	currentNode = *CurrentNode;

    switch(CurrentCharacter) {
    
    case 'H':
    case 'h':
        {

            nodeType = HOST_BRIDGE;

			break;

        }

	case 'P':
	case 'p':
		{

			nodeType = P2P;

			break;

		}

    case 'D':
    case 'd':
        {
            nodeType = DEVICE;

            break;

        }

	case 'R':
    case 'r':
        {
            nodeType = ROOT_PORT;

            break;

        }

    case 'U':
    case 'u':
        {
            nodeType = UP_STREAM;

            break;
        }

    case 'S':
    case 's':
        {
            nodeType = DOWN_STREAM;

            break;
        }

    case '(':
        {
            this->CreateStatus = LEFT_CHILD;

            goto Exit;
        }

    case ')':
        {

            currentNode = currentNode->GetParent();

            this->CreateStatus = RIGHT_SIBLING;

            goto Exit;
        }

    case ',':
        {
            this->CreateStatus = RIGHT_SIBLING;

            goto Exit;
        }

    case ' ':
    case '\t':
    case '\n':
        {
            goto Exit;
        }

    default:
        {
            status = false;

            goto Exit;
        }

    }

    if (this->CreateStatus == LEFT_CHILD) {

        //
        // We are creating a new left child.
        // 

		if (nodeType == DEVICE || nodeType == HOST_BRIDGE) {

			currentNode->LeftChild = new CDeviceNode(currentNode, nodeType);

		} else {

			currentNode->LeftChild = new CBridgeNode(currentNode, nodeType);

		}

        currentNode = currentNode->LeftChild;

    } else {

        //
        // We are creating a right sibling for the current node.
        // 
		
		if (nodeType == DEVICE || nodeType == HOST_BRIDGE) {

			currentNode->RightSibling = new CDeviceNode(currentNode->GetParent(), nodeType);

		} else {

			currentNode->RightSibling = new CBridgeNode(currentNode->GetParent(), nodeType);

		}
		
		currentNode = currentNode->RightSibling;

    }

Exit:

	*CurrentNode = currentNode;

    return status;

}

bool
CDeviceTree::AssignBusNumbers()
{
	
	

	bool status = true;

	CDeviceNode *currentNode = this->RootNode;;

	CDeviceNode *childNode;
	
	DEVICE_NODE_QUEUE devNodeQueue;

	if (this->RootNode == NULL) {

		return false;

	}
	

//	this->RootNode->BusNumberMap.set(0);

	//
	//Preorder traversal of deapth first search to enqueue all nodes in order
	//

	do{
		if (currentNode && currentNode->LeftChild != NULL) {

			currentNode = currentNode->LeftChild;
			currentNode->PrimaryBusNumber = FindNextBusStartPos(); 
			currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
			this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
			UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));

		}

		else if (currentNode && currentNode->RightSibling != NULL) {

			currentNode = currentNode->RightSibling;

			if (currentNode->GetParent())
			{
				currentNode->PrimaryBusNumber = currentNode->GetParent()->LeftChild->PrimaryBusNumber;

				currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
				this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
				UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));
			}

		}

		else if (currentNode && currentNode->RightSibling == NULL) {

			currentNode = currentNode->GetParent();
			
			while (currentNode != NULL && currentNode->RightSibling == NULL) {

				currentNode = currentNode->GetParent();

			}

			if (currentNode != NULL && currentNode->RightSibling != NULL) {

				currentNode = currentNode->RightSibling;

				if (currentNode && currentNode->GetParent())
				{
					currentNode->PrimaryBusNumber = currentNode->GetParent()->LeftChild->PrimaryBusNumber;

					currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
					this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
					UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));
				}

			}

		}


	} while (currentNode != NULL);

	return status;
	
	}
int
CDeviceTree::FindNextBusStartPos()
{

	int i;
	for (i = 0; i < 255; i++)
	{
	
		if (!this->RootNode->BusNumberMap.test(i))
		
		{
		
			break;
		
		}

	}
	return (i + 0);
}


void
CDeviceTree::UpdateAncestorSubordinateBusNumbers(CBridgeNode* ParentNode, unsigned __int8 BusNumber)
{
	
	while (ParentNode != NULL)
	{

		ParentNode->BusNumberMap.set(BusNumber);
		
		ParentNode = (CBridgeNode*) ParentNode->GetParent();
	}
}

void
CDeviceTree::DisplayTree()
{
	//
	// Lets do inorder traversal of the tree to display it.
	//

	unsigned __int8 tabCount = 0;

	CDeviceNode* currentNode;

	if (this->RootNode == NULL)
	{
		return;
	}

	currentNode = this->RootNode;

	while (currentNode != NULL)
	{
		currentNode->PrintDeviceNode(tabCount);

		if (currentNode->LeftChild != NULL) {

			tabCount++;

			currentNode = currentNode->LeftChild;

			continue;

		} else if (currentNode->RightSibling != NULL) {

			currentNode = currentNode->RightSibling;

			continue;

		} else {

			do
			{

				tabCount--;

				currentNode = currentNode->GetParent();

			} while (currentNode != NULL && currentNode->RightSibling == NULL);

			if (currentNode != NULL)
			{
				currentNode = currentNode->RightSibling;
			}

		}
	}
}


// 
//Compare the two trees to construct the updated config file
//

void
CDeviceTree::UpdateTheTree(CDeviceTree *devTree1)
{
	CDeviceNode *currentNode = this->RootNode;
	CDeviceNode *currentNode1 = devTree1->RootNode;
	CDeviceNode *backUpNode;
	CDeviceNode *backUpNode1;
	CDeviceNode *deletionNode;
	
	
	cout << "1" << endl;

	do{

		cout << "6" << endl;
		
		if (currentNode && currentNode1 && currentNode->LeftChild != NULL && currentNode1->LeftChild != NULL && currentNode->LeftChild->GetNodeType() == currentNode1->LeftChild->GetNodeType())
		{
			//Parsing through the file
			currentNode = currentNode->LeftChild;
			currentNode1 = currentNode1->LeftChild;

			cout << "7" << endl;
			
			
		}

		else if (currentNode && currentNode1 && currentNode->LeftChild != NULL && currentNode1->LeftChild != NULL && currentNode->LeftChild->GetNodeType() != currentNode1->LeftChild->GetNodeType())
		{

			cout << "8" << endl;
			cout << "invalid config file" << endl;
			goto Exit;

		}

		else if (currentNode && currentNode1 && currentNode->LeftChild != NULL && currentNode1->LeftChild == NULL)
		{
			// Hot removed

			cout << "9" << endl;
			//backUpNode = currentNode;
			
			currentNode = currentNode->LeftChild;

			DeleteSubTree(currentNode);
			

			deletionNode = currentNode;


			while (currentNode && currentNode->GetParent() != NULL)
			{

				cout << "10" << endl;
				//update the bitvector of all the parent nodes in that hierarchy

					currentNode->GetParent()->BusNumberMap ^= currentNode->BusNumberMap;
					currentNode = currentNode->GetParent();
					cout << "cqqqqq" << endl;
			
			}

			cout << "11" << endl;
			currentNode = deletionNode->GetParent();
			currentNode->LeftChild = NULL;
			delete deletionNode;
			continue;

		}

		else if (currentNode && currentNode1 && currentNode->LeftChild == NULL && currentNode1->LeftChild != NULL)
		{

			cout << "12" << endl;
			// Hot adding

			backUpNode = currentNode;

			do
			{

				cout << "13" << endl;
				if (currentNode1->LeftChild != NULL && currentNode->LeftChild == NULL)
				{
					cout << "15" << endl;
		
					currentNode->LeftChild = new CDeviceNode(currentNode, currentNode1->LeftChild->GetNodeType());
			
					currentNode = currentNode->LeftChild;
					currentNode1 = currentNode1->LeftChild;

					currentNode->PrimaryBusNumber = FindNextBusStartPos();
					currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
					this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
					UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));


					currentNode->LeftChild = NULL;
					currentNode->RightSibling = NULL;

					cout << "17" << endl;
					}

				else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling == NULL)
				{

					cout << "18" << endl;
					currentNode->RightSibling = new CDeviceNode(currentNode->GetParent(), currentNode1->RightSibling->GetNodeType());
	
					currentNode = currentNode->RightSibling;
					currentNode1 = currentNode1->RightSibling;
					
					if (currentNode->GetParent() && currentNode->GetParent()->LeftChild)
					{
						currentNode->PrimaryBusNumber = currentNode->GetParent()->LeftChild->PrimaryBusNumber;
						currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
						this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
						UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));
					}
					currentNode->RightSibling = NULL;
					currentNode->LeftChild = NULL;

					cout << "21" << endl;
				}

				else if (currentNode && currentNode1 && currentNode1->RightSibling == NULL && currentNode1->LeftChild == NULL && currentNode->RightSibling == NULL && currentNode->LeftChild == NULL)
				{
					cout << "22" << endl;
					currentNode = currentNode->GetParent();
					currentNode1 = currentNode1->GetParent();

					while (currentNode && currentNode1 && currentNode->RightSibling == NULL && currentNode1->RightSibling == NULL && currentNode != backUpNode)
					{
						cout << "23" << endl;
						currentNode = currentNode->GetParent();
						currentNode1 = currentNode1->GetParent();

					}

					if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->GetNodeType() == currentNode1->GetNodeType())
					{
						cout << "24" << endl;
						currentNode = currentNode->RightSibling;
						currentNode1 = currentNode1->RightSibling;

					}

					else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->GetNodeType() != currentNode1->GetNodeType())
					{
						cout << "25" << endl;

						cout << "invalid config file" << endl;
						goto Exit;

					}
					cout << "26" << endl;
				}
				cout << "27" << endl;
			} while (currentNode != backUpNode && currentNode != NULL);
			 
			cout << "28" << endl;
			if (currentNode == backUpNode)
			{
				cout << "29" << endl;
				if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
				{
					cout << "30" << endl;
					currentNode = currentNode->RightSibling;
					currentNode1 = currentNode1->RightSibling;

				}
				else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() != currentNode1->RightSibling->GetNodeType())
				{
					cout << "invalid config file" << endl;
					goto Exit;
				}
				cout << "35" << endl;
			}

			else if (currentNode == NULL)
		{
			cout << "36" << endl;
			break;
		}
			cout << "37" << endl;
	}

		else if (currentNode && currentNode1 && currentNode->LeftChild == NULL && currentNode1->LeftChild == NULL && currentNode->RightSibling != NULL && currentNode1->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
		{
			cout << "38" << endl;
			currentNode = currentNode->RightSibling;
			currentNode1 = currentNode1->RightSibling;
		}

		else if (currentNode && currentNode1 && currentNode->LeftChild == NULL && currentNode1->LeftChild == NULL && currentNode->RightSibling != NULL && currentNode1->RightSibling != NULL && currentNode->RightSibling->GetNodeType() != currentNode1->RightSibling->GetNodeType())
		{
			cout << "39" << endl;
			cout << "invalid config file" << endl;
			goto Exit;
		
		}

		else if (currentNode && currentNode1 && currentNode->RightSibling != NULL && currentNode1->RightSibling == NULL)
		{
			cout << "40" << endl;
			// Hot removed
			backUpNode = currentNode;
			backUpNode1 = currentNode->RightSibling->RightSibling;
			currentNode = currentNode->RightSibling;
			DeleteSubTree(currentNode);
			deletionNode = currentNode;
			
			while (currentNode && currentNode->GetParent() != NULL)
			{
				cout << "41" << endl;
				//update the bitvector of all the parent nodes in that hierarchy

				currentNode->GetParent()->BusNumberMap ^= currentNode->BusNumberMap;
				currentNode = currentNode->GetParent();
				cout << "cqqqqq" << endl;

			}

			currentNode = backUpNode;
			currentNode->RightSibling = backUpNode1;
			delete deletionNode;
			cout << "42" << endl;
		}

		else if (currentNode && currentNode1 && currentNode->RightSibling == NULL && currentNode1->RightSibling != NULL)
		{
			cout << "43" << endl;
			// Hot adding

			if (currentNode && currentNode1 && currentNode->RightSibling == NULL && currentNode1->RightSibling != NULL)
			{
				cout << "44" << endl;
		
				currentNode->RightSibling = new CDeviceNode(currentNode->GetParent(), currentNode1->RightSibling->GetNodeType());
				currentNode = currentNode->RightSibling;
				currentNode1 = currentNode1->RightSibling;
				if (currentNode->GetParent())
				{
					currentNode->PrimaryBusNumber = currentNode->GetParent()->LeftChild->PrimaryBusNumber;
					currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
					this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
					UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));
				}
				currentNode->LeftChild = NULL;
				currentNode->RightSibling = NULL;
				cout << "47" << endl;
			}

			// Adding hot add from the method above 
			// Hot adding
			cout << "48" << endl;
			backUpNode = currentNode;

			do
			{
				cout << "49" << endl;

				if (currentNode && currentNode1 && currentNode1->LeftChild != NULL && currentNode->LeftChild == NULL)
				{
					cout << "50" << endl;
		
					currentNode->LeftChild = new CDeviceNode(currentNode, currentNode1->LeftChild->GetNodeType());

					currentNode = currentNode->LeftChild;
					currentNode1 = currentNode1->LeftChild;

					currentNode->PrimaryBusNumber = FindNextBusStartPos();
					currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
					this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
					UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));


					currentNode->LeftChild = NULL;
					currentNode->RightSibling = NULL;
					cout << "53" << endl;
				}

				else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling == NULL)
				{
					cout << "54" << endl;
				
					cout << "55" << endl;
			
					currentNode->RightSibling = new CDeviceNode(currentNode->GetParent(), currentNode1->RightSibling->GetNodeType());

					currentNode = currentNode->RightSibling;
					currentNode1 = currentNode1->RightSibling;
					if (currentNode->GetParent())
					{
						currentNode->PrimaryBusNumber = currentNode->GetParent()->LeftChild->PrimaryBusNumber;
						currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
						this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
						UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));
					}
					currentNode->RightSibling = NULL;
					currentNode->LeftChild = NULL;
					cout << "57" << endl;
				}

				else if (currentNode && currentNode1 && currentNode1->RightSibling == NULL && currentNode1->LeftChild == NULL && currentNode->RightSibling == NULL && currentNode->LeftChild == NULL)
				{
					cout << "58" << endl;
					currentNode = currentNode->GetParent();
					currentNode1 = currentNode1->GetParent();

					while (currentNode->RightSibling == NULL && currentNode1->RightSibling == NULL && currentNode != backUpNode)
					{
						cout << "59" << endl;
						currentNode = currentNode->GetParent();
						currentNode1 = currentNode1->GetParent();

					}

					if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
					{
						cout << "60" << endl;
						currentNode = currentNode->RightSibling;
						currentNode1 = currentNode1->RightSibling;

					}

					else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() != currentNode1->RightSibling->GetNodeType())
					{
						cout << "61" << endl;

						cout << "invalid config file" << endl;
						goto Exit;

					}
					cout << "62" << endl;
				}
				cout << "63" << endl;
			} while (currentNode != backUpNode && currentNode != NULL);
			cout << "64" << endl;

			if (currentNode == backUpNode)
			{
				cout << "65" << endl;
				if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
				{
					cout << "66" << endl;
					currentNode = currentNode->RightSibling;
					currentNode1 = currentNode1->RightSibling;

				}
				else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() != currentNode1->RightSibling->GetNodeType())
				{
					cout << "invalid config file" << endl;
					goto Exit;
				}

				else if (currentNode && currentNode1 &&  currentNode->RightSibling == NULL && currentNode1->RightSibling == NULL)
				{
					cout << "67" << endl;
					while (currentNode && currentNode1 &&  currentNode->RightSibling == NULL && currentNode1->RightSibling == NULL)
					{

						currentNode = currentNode->GetParent();
						currentNode1 = currentNode1->GetParent();

					}

					if (currentNode && currentNode1 &&  currentNode->RightSibling != NULL && currentNode1->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
					{
						cout << "68" << endl;
						currentNode = currentNode->RightSibling;
						currentNode1 = currentNode1->RightSibling;

					}
					cout << "69" << endl;
				}
				cout << "70" << endl;
			}
			
			else if (currentNode == NULL)
			{
				cout << "71" << endl;
				break;
			}
			cout << "72" << endl;
		}
		else if (currentNode && currentNode1 && currentNode1->RightSibling == NULL && currentNode1->LeftChild == NULL && currentNode->RightSibling == NULL && currentNode->LeftChild == NULL)
		{
			cout << "100" << endl;
			currentNode = currentNode->GetParent();
			currentNode1 = currentNode1->GetParent();

			while (currentNode && currentNode1 && currentNode->RightSibling == NULL && currentNode1->RightSibling == NULL)
			{
				cout << "159" << endl;
				currentNode = currentNode->GetParent();
				currentNode1 = currentNode1->GetParent();

			}

			if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
			{
				cout << "160" << endl;
				currentNode = currentNode->RightSibling;
				currentNode1 = currentNode1->RightSibling;

			}
			else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() != currentNode1->RightSibling->GetNodeType())
			{
				cout << "invalid config file" << endl;
				goto Exit;
			}
			else if (currentNode && currentNode1 && currentNode->RightSibling != NULL && currentNode1->RightSibling == NULL)
			{
				// Hot removal

				cout << "40" << endl;
				// Hot removed
				backUpNode = currentNode;
				backUpNode1 = currentNode->RightSibling->RightSibling;
				currentNode = currentNode->RightSibling;
				DeleteSubTree(currentNode);
				deletionNode = currentNode;

				while (currentNode && currentNode->GetParent() != NULL)
				{
					cout << "41" << endl;
					//update the bitvector of all the parent nodes in that hierarchy

					currentNode->GetParent()->BusNumberMap ^= currentNode->BusNumberMap;
					currentNode = currentNode->GetParent();
					cout << "cqqqqq" << endl;

				}

				currentNode = backUpNode;
				currentNode->RightSibling = backUpNode1;
				delete deletionNode;
				cout << "42" << endl;
			}

			
			else if (currentNode && currentNode1 && currentNode->RightSibling == NULL && currentNode1->RightSibling != NULL)
			{
				// Hot adding
			
				cout << "43" << endl;
				// Hot adding

				if (currentNode && currentNode1 && currentNode->RightSibling == NULL && currentNode1->RightSibling != NULL)
				{
					cout << "44" << endl;

					currentNode->RightSibling = new CDeviceNode(currentNode->GetParent(), currentNode1->RightSibling->GetNodeType());

					currentNode = currentNode->RightSibling;
					currentNode1 = currentNode1->RightSibling;
					if (currentNode->GetParent())
					{
						currentNode->PrimaryBusNumber = currentNode->GetParent()->LeftChild->PrimaryBusNumber;
						currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
						this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
						UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));
					}
					currentNode->LeftChild = NULL;
					currentNode->RightSibling = NULL;
					cout << "47" << endl;
				}

				// Adding hot add from the method above 
				// Hot adding
				cout << "48" << endl;
				backUpNode = currentNode;

				do
				{
					cout << "49" << endl;

					if (currentNode && currentNode1 && currentNode1->LeftChild != NULL && currentNode->LeftChild == NULL)
					{
						cout << "50" << endl;

	
						currentNode->LeftChild = new CDeviceNode(currentNode, currentNode1->LeftChild->GetNodeType());

						currentNode = currentNode->LeftChild;
						currentNode1 = currentNode1->LeftChild;

						currentNode->PrimaryBusNumber = FindNextBusStartPos();
						currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
						this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
						UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));


						currentNode->LeftChild = NULL;
						currentNode->RightSibling = NULL;
						cout << "53" << endl;
					}

					else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling == NULL)
					{
						cout << "54" << endl;

						cout << "55" << endl;
			
						currentNode->RightSibling = new CDeviceNode(currentNode->GetParent(), currentNode1->RightSibling->GetNodeType());

						currentNode = currentNode->RightSibling;
						currentNode1 = currentNode1->RightSibling;

						if (currentNode->GetParent())
						{
							currentNode->PrimaryBusNumber = currentNode->GetParent()->LeftChild->PrimaryBusNumber;
							currentNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
							this->RootNode->BusNumberMap.set((currentNode->PrimaryBusNumber - 0));
							UpdateAncestorSubordinateBusNumbers((CBridgeNode*)currentNode, (currentNode->PrimaryBusNumber - 0));
						}
						currentNode->RightSibling = NULL;
						currentNode->LeftChild = NULL;
						cout << "57" << endl;
					}

					else if (currentNode && currentNode1 && currentNode1->RightSibling == NULL && currentNode1->LeftChild == NULL && currentNode->RightSibling == NULL && currentNode->LeftChild == NULL)
					{
						cout << "58" << endl;
						currentNode = currentNode->GetParent();
						currentNode1 = currentNode1->GetParent();

						while (currentNode && currentNode1 && currentNode->RightSibling == NULL && currentNode1->RightSibling == NULL && currentNode != backUpNode)
						{
							cout << "59" << endl;
							currentNode = currentNode->GetParent();
							currentNode1 = currentNode1->GetParent();

						}

						if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
						{
							cout << "60" << endl;
							currentNode = currentNode->RightSibling;
							currentNode1 = currentNode1->RightSibling;

						}

						else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() != currentNode1->RightSibling->GetNodeType())
						{
							cout << "61" << endl;

							cout << "invalid config file" << endl;
							goto Exit;

						}
						cout << "62" << endl;
					}
					cout << "63" << endl;
				} while (currentNode != backUpNode && currentNode != NULL);
				cout << "64" << endl;

				if (currentNode == backUpNode)
				{
					cout << "65" << endl;
					if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
					{
						cout << "66" << endl;
						currentNode = currentNode->RightSibling;
						currentNode1 = currentNode1->RightSibling;

					}
					else if (currentNode && currentNode1 && currentNode1->RightSibling != NULL && currentNode->RightSibling != NULL && currentNode->RightSibling->GetNodeType() != currentNode1->RightSibling->GetNodeType())
					{
						cout << "invalid config file" << endl;
						goto Exit;
					}

					else if (currentNode && currentNode1 &&  currentNode->RightSibling == NULL && currentNode1->RightSibling == NULL)
					{
						cout << "67" << endl;
						while (currentNode && currentNode1 &&  currentNode->RightSibling == NULL && currentNode1->RightSibling == NULL)
						{

							currentNode = currentNode->GetParent();
							currentNode1 = currentNode1->GetParent();

						}

						if (currentNode && currentNode1 &&  currentNode->RightSibling != NULL && currentNode1->RightSibling != NULL && currentNode->RightSibling->GetNodeType() == currentNode1->RightSibling->GetNodeType())
						{
							cout << "68" << endl;
							currentNode = currentNode->RightSibling;
							currentNode1 = currentNode1->RightSibling;

						}
						cout << "69" << endl;
					}
					cout << "70" << endl;
				}

				else if (currentNode == NULL)
				{
					cout << "71" << endl;
					break;
				}
				cout << "72" << endl;
			}



		}

		cout << "73" << endl;
	} while (currentNode && currentNode1);
	
	cout << "74" << endl;
	
	this->DisplayTree();

	cout << "75" << endl;

Exit:
	cout << "76" << endl;

	cout << " " << endl;
	
}


void
CDeviceTree::DeleteTree()
{

	//
	// Lets now do post order traversal to cleanup the tree.
	//

	CDeviceNode* deletionNode;

	CDeviceNode* currentNode;

	if (this->RootNode == NULL)
	{
		return;
	}

	currentNode = this->RootNode;

	while (currentNode != NULL)
	{

		if (currentNode->LeftChild != NULL) {

			currentNode = currentNode->LeftChild;

			continue;

		} else if (currentNode->RightSibling != NULL) {

			deletionNode = currentNode;

			currentNode = currentNode->RightSibling;

			currentNode->GetParent()->LeftChild = currentNode;

			delete deletionNode;

			continue;

		} else {

			do
			{

				deletionNode = currentNode;

				currentNode = currentNode->GetParent();

				if (currentNode != NULL)
				{
					currentNode->LeftChild = NULL;
				}

				delete deletionNode;

			} while (currentNode != NULL && currentNode->RightSibling == NULL);

		}

	}	
}

void
CDeviceTree::DeleteSubTree(CDeviceNode* currentNode)
{

	//
	// Lets now do post order traversal to cleanup the tree.
	//

	CDeviceNode* deletionNode;
	CDeviceNode* BackUpNode;
	BackUpNode = currentNode;

	//CDeviceNode* currentNode;

	if (currentNode->LeftChild == NULL)
	{
		return;
	}

	//currentNode = this->RootNode;

	do
	{

		if (currentNode->LeftChild != NULL) {

			currentNode = currentNode->LeftChild;

			continue;

		}
		else if (currentNode->RightSibling != NULL) {

			deletionNode = currentNode;

			currentNode = currentNode->RightSibling;

			currentNode->GetParent()->LeftChild = currentNode;

			delete deletionNode;

			continue;

		}
		else {

			do
			{

				deletionNode = currentNode;

				currentNode = currentNode->GetParent();

				if (currentNode != NULL)
				{
					currentNode->LeftChild = NULL;
				}

				delete deletionNode;

			} while (currentNode != NULL && currentNode->RightSibling == NULL && currentNode != BackUpNode);

		}

	} while (currentNode != NULL && currentNode != BackUpNode);
}

CDeviceTree::~CDeviceTree()
{
	DeleteTree();	
}
