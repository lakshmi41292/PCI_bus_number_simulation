#include "stdafx.h"

#include <iostream>
#include <bitset>
#include "DeviceNode.h"

using namespace std;



CDeviceNode::CDeviceNode(CDeviceNode *Parent, NODE_TYPE NodeType)
{
    this->Parent = Parent;

    this->NodeType = NodeType;

    this->LeftChild = NULL;

    this->RightSibling = NULL;
    
    this->PrimaryBusNumber = 0;
	
	BusNumberMap.reset(); 
}

void
CDeviceNode::PrintDeviceNode(unsigned short TabCount)
{
	long double longint = 0;
	
	while (TabCount != 0)
	{

		cout << "\t";

		TabCount--;

	}

	switch (this->NodeType)
	{
	case DEVICE:
	{
		cout << "DEVICE -> ";

		break;
	}

	case HOST_BRIDGE:
	{
		cout << "HOST BRIDGE -> ";

		break;
	}

//	case DEV_TREE_ROOT:
//	{
	//	cout << "DEV_TREE_ROOT -> ";

	//	break;
	//}

	case P2P:
	{
		cout << "P2P BRIDGE -> ";

		break;
	}
	case ROOT_PORT:
	{
		cout << "ROOT_PORT -> ";

		break;
	}
	case UP_STREAM:
	{
		cout << "UP_STREAM PORT -> ";

		break;
	}
	case DOWN_STREAM:
	{
		cout << "DOWN_STREAM PORT -> ";

		break;
	}
	}
	if (this->NodeType != DEV_TREE_ROOT)
	{
		cout << hex << "0x" << (int)this->PrimaryBusNumber << endl;
		cout << this->BusNumberMap << endl;
	}
}

CDeviceNode*
CDeviceNode::GetParent()
{
	
		return this->Parent;
	
}




NODE_TYPE
CDeviceNode::GetNodeType()
{
    return this->NodeType;
}

CDeviceNode::~CDeviceNode()
{
	//
	// Fill in with destructor functionality.
	//
}
