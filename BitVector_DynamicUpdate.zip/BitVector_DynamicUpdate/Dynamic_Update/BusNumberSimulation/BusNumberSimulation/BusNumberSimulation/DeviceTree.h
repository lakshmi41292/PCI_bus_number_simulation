#pragma once

#include "BridgeNode.h"


class CDeviceTree
{
private:

    //
    // Define the map for storing the bus number allocations.
    // 
 

    CREATE_STATUS CreateStatus;

    CBridgeNode *RootNode;

	unsigned __int8 MaxBusNumber;

    //
    // Private member function declaration.
    // 

    bool ConstructNextNode(char CurrentCharacter, CDeviceNode** CurrentNode);

    bool AssignBusNumbers();

	void UpdateAncestorSubordinateBusNumbers(CBridgeNode* CurrentNode, unsigned __int8 BusNumber);

	int FindNextBusStartPos();

	void DeleteTree();

	void DeleteSubTree(CDeviceNode* currentNode);

public:

    //
    // Constructor and Destructor declaration.
    // 
	
    CDeviceTree(unsigned __int8 StartBusNumber, unsigned __int8 EndBusNumber);

    ~CDeviceTree();

    bool ConstructDeviceTree(char *FileName);

	// 
	//Comparing the two trees to construct the updated config file
	//
	void UpdateTheTree(CDeviceTree *devTree);
	void DeleteSubTree();
	//CDeviceNode* preorder();

	void DisplayTree();

};
