#pragma once

#include "Def.h"

#include <bitset>


const int BUS_NUMBER_MAP_BYTE_COUNT = 32;//vj
class CDeviceNode 
{

protected:

    //
    // Private Member Variables
    // 
	
    CDeviceNode *Parent;

    NODE_TYPE NodeType;

public:

    //
    // Public Member Variables
    // 
	//char BusNumberMap[BUS_NUMBER_MAP_BYTE_COUNT];//vj
	std::bitset < 25 > BusNumberMap;

	int PrimaryBusNumber;

    CDeviceNode *LeftChild;

    CDeviceNode *RightSibling;

	unsigned int Tempnumber;

	int a;

    //
    // Constructor Declaration
    // 

    CDeviceNode(CDeviceNode *Parent, NODE_TYPE NodeType);

    //
    // Member Functions
    // 

    virtual void PrintDeviceNode(unsigned short TabCount);

    //
    // Accessor Functions
    // 

    CDeviceNode* GetParent();
//	CDeviceNode* preorder();

    NODE_TYPE GetNodeType();
//	void UpdateBusNumberMap(unsigned __int8 BusNumber);//vj

	//
	// Virtual Destructor declaration.
	//

	virtual ~CDeviceNode();
};
