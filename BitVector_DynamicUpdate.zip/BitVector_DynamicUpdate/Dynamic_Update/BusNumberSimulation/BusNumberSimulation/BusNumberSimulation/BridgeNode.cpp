#include "stdafx.h"

#include <iostream>

#include "BridgeNode.h"

using namespace std;

CBridgeNode::CBridgeNode(CDeviceNode *Parent, NODE_TYPE NodeType) : CDeviceNode(Parent, NodeType)
{

    this->SecondaryBusNumber = 0;

    this->SubordinateBusNumber = 0;
}

void
CBridgeNode::PrintDeviceNode(unsigned short TabCount)
{
	long double longint = 0;
	while (TabCount != 0)
	{

		cout << "\t";

		TabCount--;

	}

	switch (this->NodeType)
	{
	//case DEV_TREE_ROOT:
		//{
		//	cout << hex << "DEV_TREE_ROOT -> 0x" << (int)this->SecondaryBusNumber << endl;// " END BUS NUMBER -> 0x" << (int)this->SubordinateBusNumber << endl << endl;
		//	cout << this->BusNumberMap << endl;
		//	return;
	//	}

	case P2P:
		{
			cout << "P2P BRIDGE -> ";

			break;
		}

	case ROOT_PORT:
		{
			cout << "ROOT PORT -> ";

			break;
		}

	case UP_STREAM:
		{
			cout << "UP STREAM PORT -> ";

			break;
		}
     
	case DOWN_STREAM:
		{
			cout << "DOWN STREAM PORT -> ";

			break;
		}
	}
	if (this->NodeType != DEV_TREE_ROOT)
	{
		cout << hex << "0x" << (int)this->PrimaryBusNumber << endl;// " -> 0x" << (int)this->SecondaryBusNumber << " -> 0x" << (int)this->SubordinateBusNumber << endl;
		cout << this->BusNumberMap << endl;
	}
}

CBridgeNode::~CBridgeNode()
{
	//
	// Fill in with destructor functionality.
	//
}
