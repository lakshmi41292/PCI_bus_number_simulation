#pragma once

#include "DeviceNode.h"

class CBridgeNode : public CDeviceNode
{

public:

    unsigned __int8 SecondaryBusNumber;

    unsigned __int8 SubordinateBusNumber;

    //
    // Constructor Declaration
    // 

    CBridgeNode(CDeviceNode *Parent, NODE_TYPE NodeType);

    //
    // Member Functions
    // 

    void PrintDeviceNode(unsigned short TabCount);

	//
	// Destructor Declaration
	//

	~CBridgeNode();

};
