// BusNumberSimulation.cpp : main project file.

#include "stdafx.h"

#include <iostream>
#include <fstream>

#include "DeviceTree.h"

using namespace std;

int __cdecl main(int argc, char* argv[], char* envp[])
{
    
	bool status;

	unsigned __int8 startBusNumber, endBusNumber;

    CDeviceTree *devTree;
	CDeviceTree *devTree1;

    //
    // Check if we have the right number of command line arguments.
    // 

    if (argc != 4) {

        cout << "BusNumberSimulation.exe <starting bus number> <ending bus number> <Path To Config File>" << endl;

        return 0;

    }

	startBusNumber = (unsigned __int8) atoi(argv[1]);

	endBusNumber = (unsigned __int8) atoi(argv[2]);
    
    //
    // Create a new device tree.
    // 

    devTree = new CDeviceTree(startBusNumber, endBusNumber);

    //
    // Construct the device tree from the config file.
    // 

    status = devTree->ConstructDeviceTree(argv[3]);

    if (!status) {

        goto Exit;

    }

	devTree->DisplayTree();
	

	//
	//Dynamic update of the config file.
	//
	
	do {
		char *string = new char[1000];
		char *ar1 = new char[500];

		cout << "Do you want to update or exit ?" << endl;
		cin.getline(string, 1000, '\n');

			if ((string[0] == 'u' || string[0] == 'U') && (string[1] == 'p' || string[1] == 'P') && (string[2] == 'd' || string[2] == 'D') && (string[3] == 'a' || string[3] == 'A') && (string[4] == 't' || string[4] == 'T') && (string[5] == 'e' || string[5] == 'E')) {

				cout << "Enter the updated config file: " << endl;
				cin >> ar1;

				//
				// Create a new device tree.
				// 

				devTree1 = new CDeviceTree(startBusNumber, endBusNumber);


				//
				// Construct the device tree from the config file.
				// 

				status = devTree1->ConstructDeviceTree(ar1);

				if (!status) {

					goto Exit;

				}


				//
				//Compare the two trees to construct the updated config file
				//

				devTree->UpdateTheTree(devTree1);

				//
				// Delete the new device tree duplicate to free the memeory.
				// 

				delete devTree1;



				//
				//Displaying the updated tree 
				//

				//	devTree->DisplayTree();

				//
				// Freeing memory to accept new values of the config file and string value.
				// 
				delete[]ar1;
				delete[]string;

			}


			else if ((string[0] == 'e' || string[0] == 'E') && (string[1] == 'x' || string[1] == 'X') && (string[2] == 'i' || string[2] == 'I') && (string[3] == 't' || string[3] == 'T')) {

				goto Exit;

			}

			else {

				cout << "Illegal input entered. " << endl;
				delete[]string;
			}
		} while (1);
	
	
Exit:

    //
    // Delete device tree.
    // 

    delete devTree;

    return 0;
}
